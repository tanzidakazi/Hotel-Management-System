<!DOCTYPE html>
<html>
<script type="text/javascript">
    var imgPath=["banner1.jpg","banner2.jpg","banner3.jpg"];
    var curr=-1;
    var bannerImg=new Array();
    for(i=0;i<imgPath.length;i++) {
        bannerImg[i]=new Image();
        bannerImg[i].src=imgPath[i];
    }
    function changeImage() {
        curr=(curr+1<imgPath.length)?curr+1:0;
        banner.src=bannerImg[curr].src;
        setTimeout(changeImage,3000);
    }
    window.onload=function () {
        banner=document.getElementById("imgBanner");
        changeImage();
    }

</script>
<head>
    <link rel="stylesheet" href="styles.css">
    <title>Demo Hotel</title>
</head>

<body>
<div class="header">
    <img class="header_img" src="logo.png" alt=""/>
    <ul>
        <li><a href="">Contact Us</a></li>
        <li><a href="">Reservation</a></li>
        <li><a href="">About</a></li>
        <li><a href="">Home</a></li>
    </ul>
</div>
<div class="banner">
    <img class="banner_img" id="imgBanner" src="" alt=""/>
</div>

</body>
</html>